from fastapi.testclient import TestClient

from supportdesk_env.environment import SupportDeskEnvironment
from supportdesk_env.models import (
    ActionType,
    SupportAction,
    TicketCategory,
    TicketPriority,
    TicketTeam,
)
from supportdesk_env.server import app


def test_easy_task_can_score_perfectly():
    env = SupportDeskEnvironment()
    env.reset("easy_refund_request")
    env.step(SupportAction(action_type=ActionType.VIEW_QUEUE))
    env.step(SupportAction(action_type=ActionType.OPEN_TICKET, ticket_id="E-101"))
    env.step(
        SupportAction(
            action_type=ActionType.CLASSIFY_TICKET,
            ticket_id="E-101",
            category=TicketCategory.BILLING,
            priority=TicketPriority.HIGH,
        )
    )
    env.step(
        SupportAction(
            action_type=ActionType.ASSIGN_TEAM,
            ticket_id="E-101",
            assigned_team=TicketTeam.BILLING_OPS,
        )
    )
    env.step(
        SupportAction(
            action_type=ActionType.DRAFT_REPLY,
            ticket_id="E-101",
            draft_reply=(
                "We confirmed the duplicate charge and started a refund. "
                "The refund for the duplicate charge should appear within 3-5 business days."
            ),
        )
    )
    env.step(
        SupportAction(
            action_type=ActionType.RESOLVE_TICKET,
            ticket_id="E-101",
            resolution_note="Billing ops confirmed refund workflow.",
        )
    )
    result = env.step(SupportAction(action_type=ActionType.SUBMIT_TASK))

    assert result.done is True
    assert result.info["final_score"] == 1.0


def test_partial_grading_is_deterministic():
    env = SupportDeskEnvironment()
    env.reset("medium_multi_queue")
    env.step(SupportAction(action_type=ActionType.OPEN_TICKET, ticket_id="M-201"))
    env.step(
        SupportAction(
            action_type=ActionType.CLASSIFY_TICKET,
            ticket_id="M-201",
            category=TicketCategory.ACCOUNT_ACCESS,
            priority=TicketPriority.MEDIUM,
        )
    )
    result = env.step(SupportAction(action_type=ActionType.SUBMIT_TASK))

    assert result.done is True
    assert 0.0 < result.info["final_score"] < 1.0


def test_fastapi_routes_work():
    client = TestClient(app)
    reset_response = client.post("/reset", json={"task_id": "easy_refund_request"})
    assert reset_response.status_code == 200
    step_response = client.post("/step", json={"action_type": "view_queue"})
    assert step_response.status_code == 200
    state_response = client.get("/state")
    assert state_response.status_code == 200
