from __future__ import annotations

import uuid
from copy import deepcopy
from typing import Dict, Optional

from supportdesk_env.graders import grade_task
from supportdesk_env.models import (
    ActionType,
    RewardSignal,
    StepResponse,
    SupportAction,
    SupportObservation,
    SupportState,
    TaskSpec,
    TicketRecord,
)
from supportdesk_env.tasks import TASKS


class SupportDeskEnvironment:
    def __init__(self) -> None:
        self._task: Optional[TaskSpec] = None
        self._state: Optional[SupportState] = None
        self._visited_queue = False

    def available_tasks(self):
        return list(TASKS.keys())

    def reset(self, task_id: Optional[str] = None) -> SupportObservation:
        selected_task_id = task_id or "easy_refund_request"
        if selected_task_id not in TASKS:
            raise ValueError("Unknown task_id: {0}".format(selected_task_id))

        self._task = TASKS[selected_task_id]
        self._visited_queue = False
        tickets = [
            TicketRecord(
                ticket_id=ticket.ticket_id,
                customer=ticket.customer,
                subject=ticket.subject,
                body=ticket.body,
            )
            for ticket in self._task.tickets
        ]
        self._state = SupportState(
            episode_id=str(uuid.uuid4()),
            task_id=self._task.task_id,
            difficulty=self._task.difficulty,
            objective=self._task.objective,
            step_count=0,
            max_steps=self._task.max_steps,
            done=False,
            cumulative_reward=0.0,
            grader_score=0.0,
            tickets=tickets,
            action_history=[],
        )
        return self._build_observation("Environment reset.")

    def state(self) -> SupportState:
        if self._state is None or self._task is None:
            raise RuntimeError("Environment has not been reset.")
        grader = grade_task(self._state, self._task)
        state = self._state.model_copy(deep=True)
        state.grader_score = grader["score"]
        return state

    def step(self, action: SupportAction) -> StepResponse:
        if self._state is None or self._task is None:
            raise RuntimeError("Call reset() before step().")
        if self._state.done:
            raise RuntimeError("Episode already completed. Call reset() to start a new one.")

        self._state.step_count += 1
        self._state.action_history.append(action)

        reward_signal = self._apply_action(action)
        self._state.cumulative_reward += reward_signal.score

        info: Dict[str, object] = {
            "episode_id": self._state.episode_id,
            "task_id": self._state.task_id,
        }

        if action.action_type == ActionType.SUBMIT_TASK:
            self._state.done = True
        elif self._state.step_count >= self._state.max_steps:
            self._state.done = True
            reward_signal.score = round(reward_signal.score - 0.25, 4)
            reward_signal.components["step_limit"] = -0.25
            reward_signal.rationale = "{0} Step limit reached.".format(reward_signal.rationale).strip()
            self._state.cumulative_reward = round(self._state.cumulative_reward - 0.25, 4)

        if self._state.done:
            grader = grade_task(self._state, self._task)
            self._state.grader_score = grader["score"]
            info["grader"] = grader
            info["final_score"] = grader["score"]
            if action.action_type == ActionType.SUBMIT_TASK:
                reward_signal.score = round(reward_signal.score + grader["score"], 4)
                reward_signal.components["final_grader_bonus"] = grader["score"]
                reward_signal.rationale = "{0} Final grading applied.".format(reward_signal.rationale).strip()
                self._state.cumulative_reward = round(self._state.cumulative_reward + grader["score"], 4)

        observation = self._build_observation(reward_signal.rationale or "Action processed.")
        observation.last_action = action.action_type.value
        observation.last_reward = reward_signal.score

        return StepResponse(
            observation=observation,
            reward=reward_signal.score,
            reward_signal=reward_signal,
            done=self._state.done,
            info=info,
        )

    def _apply_action(self, action: SupportAction) -> RewardSignal:
        components: Dict[str, float] = {}
        ticket = self._get_ticket(action.ticket_id)

        if action.action_type == ActionType.VIEW_QUEUE:
            delta = 0.05 if not self._visited_queue else -0.02
            self._visited_queue = True
            components["queue_awareness"] = delta
            return RewardSignal(score=round(delta, 4), components=components, rationale="Reviewed the queue.")

        if action.action_type == ActionType.OPEN_TICKET:
            if ticket is None:
                return RewardSignal(score=-0.15, components={"invalid_ticket": -0.15}, rationale="Tried to open a missing ticket.")
            self._state.active_ticket_id = ticket.ticket_id
            if ticket.ticket_id not in self._state.opened_ticket_ids:
                self._state.opened_ticket_ids.append(ticket.ticket_id)
                ticket.status = "open"
                components["ticket_context"] = 0.05
                return RewardSignal(score=0.05, components=components, rationale="Opened a new ticket.")
            components["repeat_open"] = -0.01
            return RewardSignal(score=-0.01, components=components, rationale="Re-opened an already visited ticket.")

        if ticket is None:
            return RewardSignal(score=-0.15, components={"missing_context": -0.15}, rationale="No valid ticket selected.")

        target = self._ticket_target(ticket.ticket_id)

        if action.action_type == ActionType.CLASSIFY_TICKET:
            delta = 0.0
            if action.category is not None:
                ticket.predicted_category = action.category
                category_reward = 0.15 if action.category == target.expected_category else -0.08
                components["category"] = category_reward
                delta += category_reward
            if action.priority is not None:
                ticket.predicted_priority = action.priority
                priority_reward = 0.15 if action.priority == target.expected_priority else -0.08
                components["priority"] = priority_reward
                delta += priority_reward
            ticket.status = "triaged"
            return RewardSignal(score=round(delta, 4), components=components, rationale="Updated ticket classification.")

        if action.action_type == ActionType.ASSIGN_TEAM:
            ticket.assigned_team = action.assigned_team
            team_reward = 0.20 if action.assigned_team == target.expected_team else -0.10
            ticket.status = "assigned"
            components["routing"] = team_reward
            return RewardSignal(score=round(team_reward, 4), components=components, rationale="Updated ticket routing.")

        if action.action_type == ActionType.DRAFT_REPLY:
            reply_text = (action.draft_reply or "").lower()
            ticket.draft_reply = action.draft_reply
            hits = sum(1 for keyword in target.reply_keywords if keyword.lower() in reply_text)
            misses = len(target.reply_keywords) - hits
            forbidden_hits = sum(1 for keyword in target.forbidden_reply_keywords if keyword.lower() in reply_text)
            coverage = hits / float(len(target.reply_keywords) or 1)
            delta = (0.25 * coverage) - (0.03 * misses) - (0.10 * forbidden_hits)
            components["reply_quality"] = round(delta, 4)
            ticket.status = "reply_ready"
            return RewardSignal(score=round(delta, 4), components=components, rationale="Drafted a customer reply.")

        if action.action_type == ActionType.RESOLVE_TICKET:
            ticket.resolution_note = action.resolution_note or "Resolved after triage."
            ticket.status = "resolved"
            resolved_well = (
                ticket.predicted_category == target.expected_category
                and ticket.predicted_priority == target.expected_priority
                and ticket.assigned_team == target.expected_team
                and self._reply_quality(ticket.ticket_id) >= 0.66
            )
            resolve_reward = 0.25 if resolved_well else -0.15
            if ticket.ticket_id not in self._state.completed_ticket_ids:
                self._state.completed_ticket_ids.append(ticket.ticket_id)
            components["resolution"] = resolve_reward
            return RewardSignal(score=round(resolve_reward, 4), components=components, rationale="Resolved the ticket.")

        if action.action_type == ActionType.SUBMIT_TASK:
            components["submit"] = 0.0
            return RewardSignal(score=0.0, components=components, rationale="Submitted the task for grading.")

        return RewardSignal(score=-0.10, components={"unknown_action": -0.10}, rationale="Action was not recognized.")

    def _reply_quality(self, ticket_id: str) -> float:
        ticket = self._get_ticket(ticket_id)
        if ticket is None:
            return 0.0
        target = self._ticket_target(ticket_id)
        reply_text = (ticket.draft_reply or "").lower()
        if not target.reply_keywords:
            return 1.0
        hits = sum(1 for keyword in target.reply_keywords if keyword.lower() in reply_text)
        return hits / float(len(target.reply_keywords))

    def _ticket_target(self, ticket_id: str):
        for ticket in self._task.tickets:
            if ticket.ticket_id == ticket_id:
                return ticket
        raise ValueError("Unknown ticket_id: {0}".format(ticket_id))

    def _get_ticket(self, ticket_id: Optional[str]) -> Optional[TicketRecord]:
        if self._state is None:
            return None
        selected_id = ticket_id or self._state.active_ticket_id
        if selected_id is None:
            return None
        for ticket in self._state.tickets:
            if ticket.ticket_id == selected_id:
                return ticket
        return None

    def _build_observation(self, message: str) -> SupportObservation:
        if self._state is None or self._task is None:
            raise RuntimeError("Environment has not been reset.")
        queue_summary = [
            {
                "ticket_id": ticket.ticket_id,
                "customer": ticket.customer,
                "subject": ticket.subject,
                "current_status": ticket.status,
                "current_priority": ticket.predicted_priority,
                "assigned_team": ticket.assigned_team,
            }
            for ticket in self._state.tickets
        ]
        active_ticket = self._get_ticket(self._state.active_ticket_id)
        return SupportObservation(
            task_id=self._task.task_id,
            difficulty=self._task.difficulty,
            objective=self._task.objective,
            step_count=self._state.step_count,
            max_steps=self._task.max_steps,
            steps_remaining=max(0, self._task.max_steps - self._state.step_count),
            queue_summary=queue_summary,
            active_ticket=deepcopy(active_ticket),
            completed_ticket_ids=list(self._state.completed_ticket_ids),
            last_message=message,
        )
