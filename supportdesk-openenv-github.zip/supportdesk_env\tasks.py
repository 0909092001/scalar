from supportdesk_env.models import (
    DifficultyLevel,
    TaskSpec,
    TicketCategory,
    TicketPriority,
    TicketTarget,
    TicketTeam,
)


TASKS = {
    "easy_refund_request": TaskSpec(
        task_id="easy_refund_request",
        difficulty=DifficultyLevel.EASY,
        objective=(
            "Triage the billing complaint, assign the correct team, send a grounded reply, "
            "and resolve the ticket."
        ),
        max_steps=8,
        tickets=[
            TicketTarget(
                ticket_id="E-101",
                customer="Nadia Ross",
                subject="Charged twice after plan upgrade",
                body=(
                    "I upgraded to the growth plan today and my card was charged twice for the "
                    "same April invoice. Please confirm the duplicate charge and tell me when the refund lands."
                ),
                expected_category=TicketCategory.BILLING,
                expected_priority=TicketPriority.HIGH,
                expected_team=TicketTeam.BILLING_OPS,
                reply_keywords=["refund", "duplicate charge", "3-5 business days"],
                forbidden_reply_keywords=["guarantee", "ignore"],
            )
        ],
    ),
    "medium_multi_queue": TaskSpec(
        task_id="medium_multi_queue",
        difficulty=DifficultyLevel.MEDIUM,
        objective=(
            "Process the mixed support queue by correctly triaging each ticket, routing it to "
            "the right team, writing a helpful reply, and resolving all three tickets."
        ),
        max_steps=18,
        tickets=[
            TicketTarget(
                ticket_id="M-201",
                customer="Avery Patel",
                subject="Password reset link loops back to sign in",
                body=(
                    "Every password reset email sends me back to the sign-in page without letting "
                    "me choose a new password. I have already tried twice in Chrome."
                ),
                expected_category=TicketCategory.ACCOUNT_ACCESS,
                expected_priority=TicketPriority.MEDIUM,
                expected_team=TicketTeam.CUSTOMER_SUCCESS,
                reply_keywords=["password", "reset link", "browser"],
            ),
            TicketTarget(
                ticket_id="M-202",
                customer="Northwind Analytics",
                subject="CSV export is missing two revenue columns",
                body=(
                    "The weekly revenue CSV is exporting, but two expected columns are blank after "
                    "yesterday's release. We rely on this report for finance reconciliation."
                ),
                expected_category=TicketCategory.TECHNICAL_SUPPORT,
                expected_priority=TicketPriority.MEDIUM,
                expected_team=TicketTeam.TECHNICAL_SUPPORT,
                reply_keywords=["csv", "columns", "investigate"],
            ),
            TicketTarget(
                ticket_id="M-203",
                customer="CloudPeak Systems",
                subject="Need pricing details for SSO and enterprise rollout",
                body=(
                    "We are evaluating your platform for 400 employees and need SSO pricing, "
                    "procurement steps, and a demo slot next week."
                ),
                expected_category=TicketCategory.SALES,
                expected_priority=TicketPriority.LOW,
                expected_team=TicketTeam.SALES,
                reply_keywords=["pricing", "SSO", "demo"],
            ),
        ],
    ),
    "hard_incident_escalation": TaskSpec(
        task_id="hard_incident_escalation",
        difficulty=DifficultyLevel.HARD,
        objective=(
            "Handle a high-pressure queue containing a potential account compromise, a production "
            "checkout incident, a VAT billing issue, and a product feedback request."
        ),
        max_steps=24,
        tickets=[
            TicketTarget(
                ticket_id="H-301",
                customer="Vertex Health",
                subject="Unexpected API key created by unknown admin",
                body=(
                    "We saw a new admin session from an unknown IP and an API key was created that "
                    "nobody on our team recognizes. Please lock this down and tell us what to do next."
                ),
                expected_category=TicketCategory.SECURITY,
                expected_priority=TicketPriority.URGENT,
                expected_team=TicketTeam.TRUST_SAFETY,
                reply_keywords=["security", "rotate", "API key", "investigation"],
            ),
            TicketTarget(
                ticket_id="H-302",
                customer="Mercury Commerce",
                subject="EMEA checkout failures after today's patch",
                body=(
                    "Our EMEA shoppers cannot complete checkout after the 10:30 UTC release. "
                    "Orders are failing and revenue is dropping every minute."
                ),
                expected_category=TicketCategory.TECHNICAL_SUPPORT,
                expected_priority=TicketPriority.URGENT,
                expected_team=TicketTeam.PLATFORM_ONCALL,
                reply_keywords=["incident", "checkout", "engineers", "status page"],
            ),
            TicketTarget(
                ticket_id="H-303",
                customer="Klara Schmitt",
                subject="German VAT is wrong on March invoice",
                body=(
                    "My March invoice shows the wrong VAT percentage for our German entity. "
                    "Please correct the invoice before our month-end close."
                ),
                expected_category=TicketCategory.BILLING,
                expected_priority=TicketPriority.HIGH,
                expected_team=TicketTeam.BILLING_OPS,
                reply_keywords=["VAT", "invoice", "billing"],
            ),
            TicketTarget(
                ticket_id="H-304",
                customer="BlueHarbor IT",
                subject="Request for audit logs in export workflow",
                body=(
                    "We would like role-based audit logs whenever someone exports customer data. "
                    "This is a feature request for our security review."
                ),
                expected_category=TicketCategory.PRODUCT_FEEDBACK,
                expected_priority=TicketPriority.LOW,
                expected_team=TicketTeam.PRODUCT_OPS,
                reply_keywords=["feature request", "audit logs", "product team"],
            ),
        ],
    ),
}
