from __future__ import annotations

from typing import Dict, List

from supportdesk_env.models import SupportState, TaskSpec, TicketRecord, TicketTarget


def _normalized(text: str) -> str:
    return (text or "").strip().lower()


def _ticket_score(record: TicketRecord, target: TicketTarget) -> Dict[str, float]:
    reply_text = _normalized(record.draft_reply or "")
    keyword_hits = sum(1 for keyword in target.reply_keywords if _normalized(keyword) in reply_text)
    forbidden_hits = sum(1 for keyword in target.forbidden_reply_keywords if _normalized(keyword) in reply_text)
    reply_score = 0.0
    if target.reply_keywords:
        reply_score = keyword_hits / float(len(target.reply_keywords))
    reply_score = max(0.0, min(1.0, reply_score - (0.25 * forbidden_hits)))

    resolved_score = 1.0 if record.status == "resolved" else 0.0
    components = {
        "category": 1.0 if record.predicted_category == target.expected_category else 0.0,
        "priority": 1.0 if record.predicted_priority == target.expected_priority else 0.0,
        "team": 1.0 if record.assigned_team == target.expected_team else 0.0,
        "reply": reply_score,
        "resolved": resolved_score,
    }
    components["total"] = round(
        (0.25 * components["category"])
        + (0.20 * components["priority"])
        + (0.25 * components["team"])
        + (0.20 * components["reply"])
        + (0.10 * components["resolved"]),
        4,
    )
    return components


def grade_task(state: SupportState, task: TaskSpec) -> Dict[str, object]:
    target_by_id = {ticket.ticket_id: ticket for ticket in task.tickets}
    breakdown: Dict[str, Dict[str, float]] = {}
    totals: List[float] = []

    for record in state.tickets:
        ticket_target = target_by_id[record.ticket_id]
        ticket_breakdown = _ticket_score(record, ticket_target)
        breakdown[record.ticket_id] = ticket_breakdown
        totals.append(ticket_breakdown["total"])

    score = round(sum(totals) / float(len(totals) or 1), 4)
    return {"score": score, "per_ticket": breakdown}
