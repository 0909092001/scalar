from __future__ import annotations

from enum import Enum
from typing import Dict, List, Optional

from pydantic import BaseModel, Field


class DifficultyLevel(str, Enum):
    EASY = "easy"
    MEDIUM = "medium"
    HARD = "hard"


class ActionType(str, Enum):
    VIEW_QUEUE = "view_queue"
    OPEN_TICKET = "open_ticket"
    CLASSIFY_TICKET = "classify_ticket"
    ASSIGN_TEAM = "assign_team"
    DRAFT_REPLY = "draft_reply"
    RESOLVE_TICKET = "resolve_ticket"
    SUBMIT_TASK = "submit_task"


class TicketCategory(str, Enum):
    BILLING = "billing"
    ACCOUNT_ACCESS = "account_access"
    TECHNICAL_SUPPORT = "technical_support"
    SALES = "sales"
    SECURITY = "security"
    PRODUCT_FEEDBACK = "product_feedback"


class TicketPriority(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    URGENT = "urgent"


class TicketTeam(str, Enum):
    BILLING_OPS = "billing_ops"
    CUSTOMER_SUCCESS = "customer_success"
    TECHNICAL_SUPPORT = "technical_support"
    SALES = "sales"
    TRUST_SAFETY = "trust_safety"
    PLATFORM_ONCALL = "platform_oncall"
    PRODUCT_OPS = "product_ops"


class TicketPreview(BaseModel):
    ticket_id: str
    customer: str
    subject: str
    current_status: str
    current_priority: Optional[TicketPriority] = None
    assigned_team: Optional[TicketTeam] = None


class TicketRecord(BaseModel):
    ticket_id: str
    customer: str
    subject: str
    body: str
    status: str = "new"
    predicted_category: Optional[TicketCategory] = None
    predicted_priority: Optional[TicketPriority] = None
    assigned_team: Optional[TicketTeam] = None
    draft_reply: Optional[str] = None
    resolution_note: Optional[str] = None


class RewardSignal(BaseModel):
    score: float = Field(..., ge=-1.0, le=1.0)
    components: Dict[str, float] = Field(default_factory=dict)
    rationale: str = ""


class SupportObservation(BaseModel):
    task_id: str
    difficulty: DifficultyLevel
    objective: str
    step_count: int
    max_steps: int
    steps_remaining: int
    queue_summary: List[TicketPreview]
    active_ticket: Optional[TicketRecord] = None
    completed_ticket_ids: List[str] = Field(default_factory=list)
    last_action: Optional[str] = None
    last_message: str = ""
    last_reward: float = 0.0


class SupportAction(BaseModel):
    action_type: ActionType
    ticket_id: Optional[str] = None
    category: Optional[TicketCategory] = None
    priority: Optional[TicketPriority] = None
    assigned_team: Optional[TicketTeam] = None
    draft_reply: Optional[str] = None
    resolution_note: Optional[str] = None


class StepResponse(BaseModel):
    observation: SupportObservation
    reward: float
    reward_signal: RewardSignal
    done: bool
    info: Dict[str, object] = Field(default_factory=dict)


class ResetRequest(BaseModel):
    task_id: Optional[str] = None


class ResetResponse(BaseModel):
    observation: SupportObservation


class SupportState(BaseModel):
    episode_id: str
    task_id: str
    difficulty: DifficultyLevel
    objective: str
    step_count: int
    max_steps: int
    done: bool
    cumulative_reward: float
    grader_score: float
    active_ticket_id: Optional[str] = None
    opened_ticket_ids: List[str] = Field(default_factory=list)
    completed_ticket_ids: List[str] = Field(default_factory=list)
    tickets: List[TicketRecord] = Field(default_factory=list)
    action_history: List[SupportAction] = Field(default_factory=list)


class TicketTarget(BaseModel):
    ticket_id: str
    customer: str
    subject: str
    body: str
    expected_category: TicketCategory
    expected_priority: TicketPriority
    expected_team: TicketTeam
    reply_keywords: List[str]
    forbidden_reply_keywords: List[str] = Field(default_factory=list)


class TaskSpec(BaseModel):
    task_id: str
    difficulty: DifficultyLevel
    objective: str
    max_steps: int
    tickets: List[TicketTarget]
