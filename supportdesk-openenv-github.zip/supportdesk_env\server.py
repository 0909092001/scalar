from fastapi import FastAPI, HTTPException

from supportdesk_env.environment import SupportDeskEnvironment
from supportdesk_env.models import ResetRequest, ResetResponse, StepResponse, SupportAction, SupportState


app = FastAPI(
    title="SupportDesk Triage Environment",
    version="0.1.0",
    description="A deterministic support operations benchmark with typed actions, observations, and rewards.",
)
env = SupportDeskEnvironment()


@app.get("/")
def root():
    return {"name": "supportdesk_triage_env", "status": "ok", "tasks": env.available_tasks()}


@app.get("/health")
def health():
    return {"status": "ok"}


@app.get("/tasks")
def tasks():
    return {"tasks": env.available_tasks()}


@app.post("/reset", response_model=ResetResponse)
def reset_environment(payload: ResetRequest = ResetRequest()):
    try:
        observation = env.reset(task_id=payload.task_id)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    return ResetResponse(observation=observation)


@app.post("/step", response_model=StepResponse)
def step_environment(action: SupportAction):
    try:
        return env.step(action)
    except (RuntimeError, ValueError) as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@app.get("/state", response_model=SupportState)
def environment_state():
    try:
        return env.state()
    except RuntimeError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
